.. |synopsis| replace::  [-1] [-f <glob>] [-h] [-I <glob>] [-j] [-l] [-n <dir>] [-r] [-t <seconds|off>] [-V] [-X <glob>] [-x]
