<h>
	Toggle the help screen.

<UP> or <k>
	Navigate the counter list one line up.

<DOWN> or <j>
	Navigate the counter list one line down.

<PAGEUP> or <b> or <CTRL-B>
	Navigate the counter list one page up.

<PAGEDOWN> or <SPACE> or <CTRL-F>
	Navigate the counter list one page down.

<HOME> or <g>
	Navigate the counter list to the top.

<END> or <G>
	Navigate the counter list to the bottom.

<d>
	Toggle between showing and hiding unseen counters. Unseen
	counters are those that has been zero for the entire runtime
	of varnishstat. Defaults to hide unseen counters.

<r>
	Toggle between showing raw and adjusted gauges. When a gauge
	is decremented faster than it is incremented, it may appear as
	a large integer with its most significant bit set. By default
	such values are adjusted to zero.

<e>
	Toggle scaling of values.

<v>
	Increase verbosity. Defaults to only showing informational
	counters.

<V>
	Decrease verbosity. Defaults to only showing informational
	counters.

<q>
	Quit.

<CTRL+T>
	Sample now.

<+>
	Increase refresh interval.

<->
	Decrease refresh interval.

