..
	Copyright (c) 2010 Varnish Software AS
	SPDX-License-Identifier: BSD-2-Clause
	See LICENSE file for full text of license

.. _phk_thoughts:

=========================
What were they thinking ?
=========================

The reason I try to write these notes is the chinese wall.

Ever since I first saw it on a school-book map, I have been wondering
what the decision making process were like.

We would like to think that the emperor asked for ideas, and that
advisors came up with analyses, budgets, cost/benefit calculations
and project plans for various proposals, and that the emperor applied
his wisdom to choose the better idea.

But it could also be, that The Assistant to The Deputy Viceminister of
Northern Affairs, edged in sideways, at a carefully chosen time where
the emperor looked relaxed and friendly, and sort of happend to mention
that 50 villages had been sort of raided by the barbarians, hoping
for the reply, which would not be a career opportunity
for The Assistant to The Assistant to The Deputy Viceminister of
Northern Affairs.

And likely as not, the emperor absentmindedly grunted "Why don't
you just build a wall to keep them out or something ?"  probably
wondering about the competence of an administration, which could
not figure out to build palisades around border villages without
bothering him and causing a monument to the Peter Principle and
Parkinssons Law to be built, which can be seen from orbit, and
possibly from the moon, if you bring your binoculars.

If somebody had written some notes, we might have known.

Poul-Henning, 2010-05-28
