..
	Copyright (c) 2012-2014 Varnish Software AS
	SPDX-License-Identifier: BSD-2-Clause
	See LICENSE file for full text of license



=========
Now what?
=========

You've read through the tutorial. You should have Varnish up and
running. You should know about the logs and you should have a rough
idea of what VCL is. Next, you might want to have a look at
:ref:`users-guide-index`, where we go through the features of
Varnish in more detail.
