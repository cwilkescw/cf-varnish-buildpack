..
	Copyright (c) 2012-2014 Varnish Software AS
	SPDX-License-Identifier: BSD-2-Clause
	See LICENSE file for full text of license


VCL Examples
------------

These are a short collection of examples that showcase some of the
capabilities of the VCL language.

.. toctree::

  vcl-example-manipulating-headers
  vcl-example-manipulating-responses
  vcl-example-acls
  vcl-example-websockets


