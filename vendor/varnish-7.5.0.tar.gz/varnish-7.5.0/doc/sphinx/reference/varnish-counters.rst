..
	Copyright (c) 2015 Varnish Software AS
	SPDX-License-Identifier: BSD-2-Clause
	See LICENSE file for full text of license

.. _varnish-counters(7):

================
varnish-counters
================

---------------------------------
Varnish counter field definitions
---------------------------------

:Manual section: 7


.. include:: ../include/counters.rst


AUTHORS
=======

This man page was written by Lasse Karstensen, using content from vsc2rst
written by Tollef Fog Heen.
